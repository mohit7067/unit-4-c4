const express =require("express");

let app =express()

var arr =[
"todo1","todo2","todo3","todo4","todo5","todo6","todo7","todo8","todo9","todo10",
]
var bag="";
function arriteration(arr){

    for(var i=0; i<arr.length; i++){

        bag+= i+1+":"+arr[i]+"/////-------////      "
    }
    return bag
}

app.get("/todo",(req,res)=>{

       res.send(arriteration(arr))
})

app.listen(2525,()=>{
    console.log("listening on 2525")
})